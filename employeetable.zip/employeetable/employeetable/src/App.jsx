// App.js
import React, { useState } from "react";
import "./App.css";

const employees = [
  { name: "Alice", department: "HR", salary: 50000 },
  { name: "Bob", department: "IT", salary: 60000 },
  { name: "Charlie", department: "Finance", salary: 55000 },
  { name: "David", department: "IT", salary: 70000 },
];

function App() {
  const [data, setData] = useState(employees);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });

  const sortTable = (key) => {
    let direction = "asc";
    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }
    const sortedData = [...data].sort((a, b) => {
      if (a[key] < b[key]) return direction === "asc" ? -1 : 1;
      if (a[key] > b[key]) return direction === "asc" ? 1 : -1;
      return 0;
    });
    setData(sortedData);
    setSortConfig({ key, direction });
  };

  return (
    <div className="App">
      <h2>Employee Table</h2>
      <table>
        <thead>
          <tr>
            <th onClick={() => sortTable("name")}>Name</th>
            <th onClick={() => sortTable("department")}>Department</th>
            <th onClick={() => sortTable("salary")}>Salary</th>
          </tr>
        </thead>
        <tbody>
          {data.map((emp, index) => (
            <tr key={index}>
              <td>{emp.name}</td>
              <td>{emp.department}</td>
              <td>{emp.salary}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;